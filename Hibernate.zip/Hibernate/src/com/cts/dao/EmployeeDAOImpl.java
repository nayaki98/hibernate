package com.cts.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	SessionFactory sessionfactory;
	Session session;
	Transaction transaction;
	@Override
	public void addEmployee(Employee e)
	{
		sessionfactory=new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		session=sessionfactory.openSession();
		transaction=session.beginTransaction();
		
		e.setEmpName("peri");
		e.setEmail("nayaki@gmail.com");
		e.setConNo("7867994602");
		session.save(e);
		
		transaction.commit();
		System.out.println("insert successfully");
		session.close();
	}
	@Override
	public void showEmployee() {
		sessionfactory=new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		session=sessionfactory.openSession();
		transaction=session.beginTransaction();
		
		Query query=session.createQuery("from Employee");
		List<Employee> list=query.list();
		for(Employee e:list)
		{
			System.out.println(e.getEmpId()+"\t"+e.getEmpName()+"\t"+e.getEmail()+"\t"+e.getConNo());
		}
		
		transaction.commit();
		System.out.println("show successfully");
		session.close();
		
	}
	@Override
	public void updateEmployee() {
		
		sessionfactory=new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		session=sessionfactory.openSession();
		transaction=session.beginTransaction();
		
		Query query=session.createQuery("update Employee set eName='preethi' where empId=3");
		query.executeUpdate();
		//query.setParameter(1, "preethi");
		//query.setParameter(2, 3);
		
		transaction.commit();
		System.out.println("update successfully");
		session.close();
	}
	@Override
	public void deleteEmployee() {
		
		sessionfactory=new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		session=sessionfactory.openSession();
		transaction=session.beginTransaction();
		
		Query query=session.createQuery("delete from Employee where empId=3");
		query.executeUpdate();
		
		
		transaction.commit();
		System.out.println("update successfully");
		session.close();
	}

}
