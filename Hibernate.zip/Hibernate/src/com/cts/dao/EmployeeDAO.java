package com.cts.dao;

import com.cts.entity.Employee;

public interface EmployeeDAO {

	void addEmployee(Employee e);
	void showEmployee();
	public void updateEmployee();
	void deleteEmployee();

}
