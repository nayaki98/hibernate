package com.cts.controller;

import com.cts.entity.Employee;
import com.cts.service.EmployeeService;
import com.cts.service.EmployeeServiceImpl;

public class EmployeeController {

	public static void main(String[] args) {
		
		EmployeeService service=new EmployeeServiceImpl();
		service.addEmployee(new Employee());
		service.showEmployee();
		service.updateEmployee();
		service.deleteEmployee();
		service.showEmployee();
	}

}
