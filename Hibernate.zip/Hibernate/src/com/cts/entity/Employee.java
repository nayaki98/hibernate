package com.cts.entity;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp_table")
public class Employee {
       @Id
       @GeneratedValue
       @Column(name="empId")
       private int empId;
       @Column(name="eName")
       private String empName;
       @Column(name="email")
       private String email;
       @Column(name="conNo")
       private String conNo;
       public int getEmpId() {
              return empId;
       }
       public void setEmpId(int empId) {
              this.empId = empId;
       }
       public String getEmpName() {
              return empName;
       }
       public void setEmpName(String empName) {
              this.empName = empName;
       }
       public String getEmail() {
              return email;
       }
       public void setEmail(String email) {
              this.email = email;
       }
       public String getConNo() {
              return conNo;
       }
       public void setConNo(String conNo) {
              this.conNo = conNo;
       }
       
       

}
