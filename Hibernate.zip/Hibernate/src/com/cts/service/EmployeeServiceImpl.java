package com.cts.service;

import com.cts.dao.EmployeeDAO;
import com.cts.dao.EmployeeDAOImpl;
import com.cts.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDAO employeeDAo=new EmployeeDAOImpl();
	@Override
	public void addEmployee(Employee e) {
		employeeDAo.addEmployee(e);
		
	}
	@Override
	public void showEmployee() {
		employeeDAo.showEmployee();
		
	}
	@Override
	public void updateEmployee() {
		employeeDAo.updateEmployee();
		
	}
	@Override
	public void deleteEmployee() {
		employeeDAo.deleteEmployee();
		
	}
	
	
	

}
