package com.cts.service;

import com.cts.entity.Employee;

public interface EmployeeService {
	
	public void addEmployee(Employee e);
	void showEmployee();
	void updateEmployee();
	void deleteEmployee();

}
